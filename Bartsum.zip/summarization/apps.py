from django.apps import AppConfig


class SummarizationConfig(AppConfig):
    name = 'summarization'
